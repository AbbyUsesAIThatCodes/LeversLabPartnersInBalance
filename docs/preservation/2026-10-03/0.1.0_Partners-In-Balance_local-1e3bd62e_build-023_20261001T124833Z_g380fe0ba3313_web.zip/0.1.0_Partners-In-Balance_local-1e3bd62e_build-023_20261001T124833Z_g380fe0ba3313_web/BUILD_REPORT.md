# Build Report

Build: `0.1.0_Partners-In-Balance_local-1e3bd62e_build-023_20261001T124833Z_g380fe0ba3313_web`

- Status: development
- Built At (UTC): 2026-10-01T12:48:33.647Z
- Source: 380fe0ba33133d36cfe7c465963cd8f19a6240c1
- Dirty Sources: false
- Input SHA-256: 4bf0fb035ad23f168d5b94730d2f0b759bca0aa6236861faeb9ce6617c80b637
- PR Head: Local or Main
- Target: web

The manifest, visible game identity, build console, and enclosing artifact directory share this identity. Test and deploy this artifact without rebuilding to preserve its identifier.
