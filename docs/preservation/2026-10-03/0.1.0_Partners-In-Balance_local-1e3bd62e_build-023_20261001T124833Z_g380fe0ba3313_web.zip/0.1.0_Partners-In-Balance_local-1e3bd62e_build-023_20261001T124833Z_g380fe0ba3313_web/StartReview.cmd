@echo off
setlocal
cd /d "%~dp0"
set "LAB_NODE=node"
if exist "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" set "LAB_NODE=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
"%LAB_NODE%" serve-review.mjs --open
if errorlevel 1 pause
